//
// Created by Lindsay Haslam on 1/18/24.
//

#ifndef EXPRESSIONCLASSES_EXPRTESTS_H
#define EXPRESSIONCLASSES_EXPRTESTS_H

#include "catch.h"
#include "Expr.h"


#endif //EXPRESSIONCLASSES_EXPRTESTS_H
