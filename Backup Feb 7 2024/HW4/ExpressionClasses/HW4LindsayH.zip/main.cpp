//#define CATCH_CONFIG_MAIN
//#include "catch.h"



#include "cmdline.h"

int main(int argc, char **argv) {
    use_arguments(argc, argv);
    return 0;
}
