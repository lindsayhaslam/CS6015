//
// Created by Lindsay Haslam on 1/11/24.
//

#ifndef HW1_CMDLINE_H
#define HW1_CMDLINE_H


//class cmdline: public main {
//
//};

void use_arguments(int argc, char **argv);


#endif //HW1_CMDLINE_H
