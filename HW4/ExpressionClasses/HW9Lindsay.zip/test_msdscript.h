//
// Created by Lindsay Haslam on 2/23/24.
//

#ifndef EXPRESSIONCLASSES_TEST_MSDSCRIPT_H
#define EXPRESSIONCLASSES_TEST_MSDSCRIPT_H

static std::string random_expr_string();

#endif //EXPRESSIONCLASSES_TEST_MSDSCRIPT_H
