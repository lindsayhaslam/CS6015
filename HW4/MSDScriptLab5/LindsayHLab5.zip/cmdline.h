//
// Created by Lindsay Haslam on 1/11/24.
//

#ifndef EXPRESSIONCLASSES_CMDLINE_H
#define EXPRESSIONCLASSES_CMDLINE_H

#include "catch.h"
#include <cstring>
#include <iostream>

//class cmdline: public main {
//
//};

void use_arguments(int argc, char **argv);


#endif //HW1_CMDLINE_H
