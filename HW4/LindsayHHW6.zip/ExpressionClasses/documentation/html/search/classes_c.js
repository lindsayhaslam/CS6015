var searchData=
[
  ['pluralise_0',['pluralise',['../struct_catch_1_1pluralise.html',1,'Catch']]],
  ['predicatematcher_1',['PredicateMatcher',['../class_catch_1_1_matchers_1_1_generic_1_1_predicate_matcher.html',1,'Catch::Matchers::Generic']]]
];
