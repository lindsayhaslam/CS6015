var searchData=
[
  ['subst_0',['subst',['../class_num.html#a062320feea11523b1c0e6f0761263f2b',1,'Num::subst()'],['../class_var.html#a03c7f3e351a27ae403556eca73096369',1,'Var::subst()'],['../class_add.html#a5f5946649fac35aff7865e34c94231d5',1,'Add::subst()'],['../class_mult.html#a48be9a4fce3980fbd3d243321d15132e',1,'Mult::subst()']]]
];
